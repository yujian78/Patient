Controllers

.controller('ReminderCtrl', function($scope) {
  
});